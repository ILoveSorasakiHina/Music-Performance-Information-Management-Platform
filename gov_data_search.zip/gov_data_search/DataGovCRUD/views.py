from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.handlers.wsgi import WSGIRequest
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import TemplateView, ListView, DetailView, DeleteView, UpdateView
from django.views.decorators.cache import cache_page
from DataGovCRUD.models import Event, ShowInfo


class OperationPageView(TemplateView):
    template_name = 'operation.html'


class HomePageView(TemplateView):
    template_name = 'home.html'


class RegisterView(View):
    def get(self, request: WSGIRequest):
        form = UserCreationForm()
        return render(request, 'register.html', {'form': form})

    def post(self, request: WSGIRequest):
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/login')
        return render(request, 'register.html', {'form': form})


class LoginView(View):
    def get(self, request: WSGIRequest):
        form = AuthenticationForm()
        return render(request, 'login.html', {'form': form})

    def post(self, request: WSGIRequest):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('operation')
        return render(request, 'login.html', {'form': form})


class LogoutView(View):
    def get(self, request: WSGIRequest):
        logout(request)
        return redirect('login')


class AllEventsView(ListView):
    queryset = Event.objects.all().order_by("hit_rate")
    template_name = 'event_list.html'
    paginate_by = 20


class EventsDetailView(DetailView):
    model = Event
    template_name = 'event_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        showinfos = ShowInfo.objects.filter(event=self.object).select_related('location')
        context['showinfos'] = showinfos
        return context


class EventDelete(LoginRequiredMixin, DeleteView):
    model = Event
    template_name = 'event_confirm_delete.html'
    success_url = reverse_lazy('operation')

    def get_object(self, queryset=None):
        pk = self.kwargs.get('pk')
        return get_object_or_404(Event, pk=pk)


class ShowInfoDelete(LoginRequiredMixin, DeleteView):
    model = ShowInfo
    template_name = 'showinfo_confirm_delete.html'
    success_url = reverse_lazy('operation')

    def get_object(self, queryset=None):
        pk = self.kwargs.get('pk')
        return get_object_or_404(ShowInfo, pk=pk)


class EventUpdateView(LoginRequiredMixin, UpdateView):
    model = Event
    fields = [
        'version', 'uid', 'title', 'category', 'description', 'image_url',
        'web_sale', 'source_web_promote', 'comment', 'edit_modify_date',
        'source_web_name', 'start_date', 'end_date', 'hit_rate', 'show_unit',
        'discount_info', 'description_filter_html', 'master_unit', 'sub_unit',
        'support_unit', 'other_unit'
    ]
    template_name = 'event_form.html'
    success_url = reverse_lazy('operation_page')

    def get_object(self, queryset=None):
        pk = self.kwargs.get('pk')
        return get_object_or_404(Event, pk=pk)


class ShowInfoUpdateView(LoginRequiredMixin, UpdateView):
    model = ShowInfo
    fields = [
        'event', 'time', 'end_time', 'on_sale', 'price', 'location'
    ]
    template_name = 'showinfo_form.html'
    success_url = reverse_lazy('showinfo_list')

    def get_object(self, queryset=None):
        pk = self.kwargs.get('pk')
        return get_object_or_404(ShowInfo, pk=pk)
